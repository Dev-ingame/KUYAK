#ifndef Fused_UTIL_INCLUDED
#define Fused_UTIL_INCLUDED

#define LEAVES_WAVES
#define WATER_WAVES
#define Fused_LIGHT vec3(0.700,0.500,0.300)
#define Fused_SHADOW vec3(0.0,0.0,0.0)
float blur = 0.005;
float in_fog = 0.25;
#define DUSK float(0.2)
float dusk1 = 0.25;
float dusk2 = 0.25;
#define Fused_TONEMAP
#define saturation 1.333
#define exposure 1.150
#define brightness 0.750
#define gamma 1.900
#define contrast 1.97
#define Fused_WORLD_LIGHT

#endif
